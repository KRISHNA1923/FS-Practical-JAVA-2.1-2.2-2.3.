function updateCount() {
    const inputText = document.getElementById("inputText").value;
    document.getElementById("charCount").textContent = inputText.length;
}

function updateCount2() {
    const inputText2 = document.getElementById("inputText2").value;
    document.getElementById("charCount2").textContent = inputText2.length;
}
